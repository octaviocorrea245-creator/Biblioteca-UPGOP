<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php echo e(__("You're logged in!")); ?>

                </div>
            </div>
        </div>
     <?php $__env->slot('header', null, []); ?> Dashboard <?php $__env->endSlot(); ?>

    <style>
        .dash-welcome {
            background: linear-gradient(135deg, #0D1B35 0%, #1A56B0 100%);
            border-radius: 16px;
            padding: 1.75rem 2rem;
            margin-bottom: 1.75rem;
            position: relative;
            overflow: hidden;
        }
        .dash-welcome::before {
            content: '';
            position: absolute;
            top: -30px; right: -30px;
            width: 180px; height: 180px;
            border-radius: 50%;
            background: rgba(255,255,255,.04);
        }
        .dash-welcome::after {
            content: '';
            position: absolute;
            bottom: -50px; right: 80px;
            width: 120px; height: 120px;
            border-radius: 50%;
            background: rgba(192,57,43,.15);
        }
        .dash-welcome h1 {
            font-family: 'Playfair Display', serif;
            color: #fff;
            font-size: 1.55rem;
            font-weight: 700;
            line-height: 1.3;
        }
        .dash-welcome p { color: rgba(255,255,255,.65); font-size: .82rem; margin-top: .35rem; }
        .dash-welcome .red-bar { height: 3px; width: 38px; background: linear-gradient(90deg,#C0392B,#E74C3C); border-radius:2px; margin: .6rem 0; }
        .welcome-badge {
            display: inline-flex; align-items: center; gap: .35rem;
            background: rgba(255,255,255,.1); border-radius: 20px;
            padding: .25rem .75rem; color: rgba(255,255,255,.75);
            font-size: .65rem; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
            margin-bottom: .6rem;
        }

        /* Stat cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
            gap: 1rem;
            margin-bottom: 1.75rem;
        }
        .stat-card {
            background: #fff;
            border-radius: 14px;
            padding: 1.3rem;
            box-shadow: 0 1px 3px rgba(13,27,53,.05), 0 4px 14px rgba(13,27,53,.04);
            border-top: 3px solid transparent;
            transition: transform .2s, box-shadow .2s;
            text-decoration: none; color: inherit; display: block;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 6px 24px rgba(13,27,53,.10); }
        .stat-icon {
            width: 42px; height: 42px; border-radius: 11px;
            display: flex; align-items: center; justify-content: center;
            margin-bottom: .9rem;
        }
        .stat-icon svg { width: 20px; height: 20px; }
        .stat-value { font-size: 1.9rem; font-weight: 700; color: #0D1B35; line-height: 1; }
        .stat-label { font-size: .75rem; color: #8496B0; margin-top: 3px; font-weight: 500; }
        .stat-sub { font-size: .7rem; margin-top: .5rem; font-weight: 600; }

        /* color variants */
        .c-blue  { border-top-color: #1A56B0; }
        .c-navy  { border-top-color: #0D1B35; }
        .c-red   { border-top-color: #C0392B; }
        .c-green { border-top-color: #27AE60; }
        .c-orange{ border-top-color: #E67E22; }
        .c-teal  { border-top-color: #16A085; }
        .c-purple{ border-top-color: #8E44AD; }

        .ic-blue   { background: rgba(26,86,176,.1);  color: #1A56B0; }
        .ic-navy   { background: rgba(13,27,53,.08);  color: #0D1B35; }
        .ic-red    { background: rgba(192,57,43,.1);  color: #C0392B; }
        .ic-green  { background: rgba(39,174,96,.1);  color: #27AE60; }
        .ic-orange { background: rgba(230,126,34,.1); color: #E67E22; }
        .ic-teal   { background: rgba(22,160,133,.1); color: #16A085; }
        .ic-purple { background: rgba(142,68,173,.1); color: #8E44AD; }

        .sub-blue   { color: #1A56B0; }
        .sub-red    { color: #C0392B; }
        .sub-green  { color: #27AE60; }
        .sub-orange { color: #E67E22; }

        /* Modules section */
        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.1rem; font-weight: 700; color: #0D1B35;
            margin-bottom: .35rem;
        }
        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
            gap: .85rem;
        }
        .mod-card {
            background: #fff;
            border-radius: 12px;
            padding: 1.2rem 1rem;
            text-align: center;
            text-decoration: none;
            color: inherit;
            box-shadow: 0 1px 3px rgba(13,27,53,.05);
            transition: all .2s;
            border: 1.5px solid #E8EDF5;
        }
        .mod-card:hover {
            border-color: #1A56B0;
            box-shadow: 0 4px 18px rgba(26,86,176,.1);
            transform: translateY(-2px);
        }
        .mod-icon {
            width: 46px; height: 46px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto .75rem;
        }
        .mod-icon svg { width: 22px; height: 22px; }
        .mod-name { font-size: .82rem; font-weight: 600; color: #2D3E58; }
        .mod-desc { font-size: .68rem; color: #8496B0; margin-top: 2px; }

        /* Divider */
        .section-divider { height: 1px; background: #E8EDF5; margin: 1.5rem 0; }
    </style>

    
    <div class="dash-welcome">
        <div class="welcome-badge">
            <svg width="10" height="10" fill="currentColor" viewBox="0 0 8 8"><circle cx="4" cy="4" r="4"/></svg>
            Sistema activo
        </div>
        <h1>Bienvenido, <?php echo e(explode(' ', Auth::user()->name)[0]); ?></h1>
        <div class="red-bar"></div>
        <p>Plataforma de gestión bibliográfica · Universidad Politécnica Gómez Palacio</p>
    </div>

    
    <div class="stats-grid">
        <a href="<?php echo e(route('libros.index')); ?>" class="stat-card c-blue">
            <div class="stat-icon ic-blue">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            </div>
            <div class="stat-value"><?php echo e($totalLibros); ?></div>
            <div class="stat-label">Libros en acervo</div>
            <div class="stat-sub sub-green"><?php echo e($librosDisponibles); ?> disponibles</div>
        </a>

        <a href="<?php echo e(route('alumnos.index')); ?>" class="stat-card c-navy">
            <div class="stat-icon ic-navy">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div class="stat-value"><?php echo e($totalAlumnos); ?></div>
            <div class="stat-label">Alumnos registrados</div>
            <div class="stat-sub sub-green"><?php echo e($alumnosActivos); ?> activos</div>
        </a>

        <a href="<?php echo e(route('prestamos.index')); ?>" class="stat-card c-teal">
            <div class="stat-icon ic-teal">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
            </div>
            <div class="stat-value"><?php echo e($prestamosActivos); ?></div>
            <div class="stat-label">Préstamos activos</div>
            <?php if($prestamosVencidos > 0): ?>
            <div class="stat-sub sub-red"><?php echo e($prestamosVencidos); ?> vencidos</div>
            <?php else: ?>
            <div class="stat-sub sub-green">Sin vencidos</div>
            <?php endif; ?>
        </a>

        <a href="<?php echo e(route('deudores.index')); ?>" class="stat-card c-red">
            <div class="stat-icon ic-red">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </div>
            <div class="stat-value"><?php echo e($deudores); ?></div>
            <div class="stat-label">Deudores</div>
            <div class="stat-sub sub-red"><?php echo e($rezagados); ?> rezagados</div>
        </a>

        <a href="<?php echo e(route('donaciones.index')); ?>" class="stat-card c-purple">
            <div class="stat-icon ic-purple">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            </div>
            <div class="stat-value"><?php echo e($donaciones); ?></div>
            <div class="stat-label">Donaciones</div>
            <div class="stat-sub sub-blue">registradas</div>
        </a>

        <a href="<?php echo e(route('adquisiciones.index')); ?>" class="stat-card c-green">
            <div class="stat-icon ic-green">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            </div>
            <div class="stat-value"><?php echo e($adquisiciones); ?></div>
            <div class="stat-label">Adquisiciones</div>
            <div class="stat-sub sub-green">por compra</div>
        </a>

        <a href="<?php echo e(route('reposiciones.index')); ?>" class="stat-card c-orange">
            <div class="stat-icon ic-orange">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
            </div>
            <div class="stat-value"><?php echo e($reposicionesPend); ?></div>
            <div class="stat-label">Reposiciones</div>
            <div class="stat-sub sub-orange">pago pendiente</div>
        </a>

        <a href="<?php echo e(route('carreras.index')); ?>" class="stat-card c-blue">
            <div class="stat-icon ic-blue">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
            </div>
            <div class="stat-value"><?php echo e($carreras); ?></div>
            <div class="stat-label">Carreras activas</div>
            <div class="stat-sub sub-blue">registradas</div>
        </a>
    </div>

    <div class="section-divider"></div>

    
    <div class="section-title">Acceso rápido</div>
    <div class="red-bar" style="margin-bottom:1.1rem;"></div>

    <div class="modules-grid">
        <a href="<?php echo e(route('libros.create')); ?>" class="mod-card">
            <div class="mod-icon ic-blue">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
            </div>
            <div class="mod-name">Nuevo Libro</div>
            <div class="mod-desc">Registrar al acervo</div>
        </a>
        <a href="<?php echo e(route('alumnos.create')); ?>" class="mod-card">
            <div class="mod-icon ic-navy">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
            </div>
            <div class="mod-name">Nuevo Alumno</div>
            <div class="mod-desc">Registrar alumno</div>
        </a>
        <a href="<?php echo e(route('prestamos.create')); ?>" class="mod-card">
            <div class="mod-icon ic-teal">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
            </div>
            <div class="mod-name">Nuevo Préstamo</div>
            <div class="mod-desc">Registrar préstamo</div>
        </a>
        <a href="<?php echo e(route('donaciones.create')); ?>" class="mod-card">
            <div class="mod-icon ic-purple">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            </div>
            <div class="mod-name">Nueva Donación</div>
            <div class="mod-desc">Registrar donación</div>
        </a>
        <a href="<?php echo e(route('adquisiciones.create')); ?>" class="mod-card">
            <div class="mod-icon ic-green">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            </div>
            <div class="mod-name">Nueva Adquisición</div>
            <div class="mod-desc">Registrar compra</div>
        </a>
        <a href="<?php echo e(route('reposiciones.create')); ?>" class="mod-card">
            <div class="mod-icon ic-orange">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
            </div>
            <div class="mod-name">Nueva Reposición</div>
            <div class="mod-desc">Pérdida o daño</div>
        </a>
        <a href="<?php echo e(route('reportes.index')); ?>" class="mod-card">
            <div class="mod-icon" style="background:rgba(13,27,53,.08);color:#0D1B35;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
            </div>
            <div class="mod-name">Reportes PDF</div>
            <div class="mod-desc">Generar reportes</div>
        </a>
        <a href="<?php echo e(route('deudores.index')); ?>" class="mod-card">
            <div class="mod-icon ic-red">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </div>
            <div class="mod-name">Deudores</div>
            <div class="mod-desc">Ver deudores</div>
        </a>
    </div>
    <div class="section-divider"></div>

    
    <?php if($proximosVencer->count() > 0): ?>
    <div class="section-title" style="color:#C0392B;">⚠ Préstamos próximos a vencer</div>
    <div class="red-bar" style="margin-bottom:1.1rem;"></div>
    <div style="background:#fff; border-radius:14px; box-shadow:0 1px 3px rgba(13,27,53,.05); overflow:hidden; margin-bottom:1.75rem; border-left:4px solid #C0392B;">        <table style="width:100%; border-collapse:collapse; font-size:.82rem;">
            <thead>
                <tr style="background:#C0392B;">
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Folio</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Alumno</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Libro</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Vence</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Días</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proximosVencer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $dias = now()->startOfDay()->diffInDays($p->fecha_devolucion_esperada->startOfDay(), false);
                ?>
                <tr style="border-top:1px solid #F5E6E6;">
                    <td style="padding:.7rem 1rem; color:#0D1B35;">#<?php echo e($p->folio); ?></td>
                    <td style="padding:.7rem 1rem; color:#0D1B35;"><?php echo e($p->alumno->nombre); ?></td>
                    <td style="padding:.7rem 1rem; color:#0D1B35;"><?php echo e(\Illuminate\Support\Str::limit($p->libro->titulo, 35)); ?></td>
                    <td style="padding:.7rem 1rem; color:#0D1B35;"><?php echo e($p->fecha_devolucion_esperada->format('d/m/Y')); ?></td>
                    <td style="padding:.7rem 1rem;">
                        <?php if($dias < 0): ?>
                            <span style="background:#FDECEA; color:#C0392B; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">VENCIDO</span>
                        <?php elseif($dias == 0): ?>
                            <span style="background:#FDECEA; color:#C0392B; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">Hoy</span>
                        <?php elseif($dias == 1): ?>
                            <span style="background:#FEF3CD; color:#E67E22; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">Mañana</span>
                        <?php else: ?>
                            <span style="background:#FEF3CD; color:#E67E22; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;"><?php echo e($dias); ?> días</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    
    <div class="section-title">Últimos préstamos registrados</div>
    <div class="red-bar" style="margin-bottom:1.1rem;"></div>
    <div style="background:#fff; border-radius:14px; box-shadow:0 1px 3px rgba(13,27,53,.05); overflow:hidden; margin-bottom:1.75rem; border-left:4px solid #1A56B0;">        <table style="width:100%; border-collapse:collapse; font-size:.82rem;">
            <thead>
                <tr style="background:#1A56B0;">
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Folio</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Alumno</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Libro</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Fecha</th>
                    <th style="padding:.75rem 1rem; text-align:left; color:#fff; font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em;">Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $ultimosPrestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $estadoLower = strtolower(trim($p->estado)); ?>
                <tr style="border-top:1px solid #E8EDF5;">
                    <td style="padding:.7rem 1rem; color:#0D1B35;">#<?php echo e($p->folio); ?></td>
                    <td style="padding:.7rem 1rem; color:#0D1B35;"><?php echo e($p->alumno->nombre); ?></td>
                    <td style="padding:.7rem 1rem; color:#0D1B35;"><?php echo e(\Illuminate\Support\Str::limit($p->libro->titulo, 35)); ?></td>
                    <td style="padding:.7rem 1rem; color:#8496B0;"><?php echo e($p->fecha_prestamo->format('d/m/Y')); ?></td>
                    <td style="padding:.7rem 1rem;">
                        <?php if($estadoLower === 'activo'): ?>
                            <span style="background:#EAFAF1; color:#27AE60; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">Activo</span>
                        <?php elseif($estadoLower === 'devuelto'): ?>
                            <span style="background:#EAF2FB; color:#1A56B0; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">Devuelto</span>
                        <?php else: ?>
                            <span style="background:#FDECEA; color:#C0392B; padding:.2rem .6rem; border-radius:20px; font-weight:600; font-size:.72rem;">Vencido</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" style="padding:1rem; text-align:center; color:#8496B0;">Sin préstamos registrados aún.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div style="padding:.75rem 1rem; text-align:right; border-top:1px solid #E8EDF5;">
            <a href="<?php echo e(route('prestamos.index')); ?>" style="font-size:.78rem; color:#1A56B0; font-weight:600; text-decoration:none;">Ver todos los préstamos →</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Biblioteca-UPGOP\resources\views/dashboard.blade.php ENDPATH**/ ?>