<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Adquisiciones</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <a href="<?php echo e(route('adquisiciones.create')); ?>"
           class="mb-4 inline-block bg-blue-600 text-white px-4 py-2 rounded">
            + Nueva Adquisición
        </a>

        <?php if(session('success')): ?>
            <div class="mb-4 text-green-600"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="mb-4">
            <input type="text" id="buscador" placeholder="Buscar por título, proveedor o carrera..."
                class="w-full border-gray-300 rounded shadow-sm p-2"
                onkeyup="buscarEnTabla()">
        </div>

        <table class="w-full bg-white shadow rounded mt-4">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-3 text-left">Código</th>
                    <th class="p-3 text-left">Título</th>
                    <th class="p-3 text-left">Autor</th>
                    <th class="p-3 text-left">Carrera</th>
                    <th class="p-3 text-left">Cantidad</th>
                    <th class="p-3 text-left">Proveedor</th>
                    <th class="p-3 text-left">Factura</th>
                    <th class="p-3 text-left">Costo</th>
                    <th class="p-3 text-left">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $adquisiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adquisicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="p-3"><?php echo e($adquisicion->codigo_adquisicion); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->titulo); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->autor); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->carrera->nombre); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->cantidad); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->proveedor); ?></td>
                    <td class="p-3"><?php echo e($adquisicion->factura); ?></td>
                    <td class="p-3">$<?php echo e(number_format($adquisicion->costo, 2)); ?></td>
                    <td class="p-3 flex gap-2">
                        <a href="<?php echo e(route('adquisiciones.edit', $adquisicion)); ?>"
                           class="bg-yellow-400 text-white px-3 py-1 rounded text-sm">Editar</a>
                        <form action="<?php echo e(route('adquisiciones.destroy', $adquisicion)); ?>" method="POST"
                              onsubmit="return confirm('¿Eliminar esta adquisición?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="bg-red-500 text-white px-3 py-1 rounded text-sm">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4">
            <?php echo e($adquisiciones->links()); ?>

        </div>
    </div>
    <script>
        function buscarEnTabla() {
            const input = document.getElementById('buscador').value.toLowerCase();
            const filas = document.querySelectorAll('tbody tr');
            filas.forEach(fila => {
                const texto = fila.innerText.toLowerCase();
                fila.style.display = texto.includes(input) ? '' : 'none';
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Biblioteca-UPGOP\resources\views/adquisiciones/index.blade.php ENDPATH**/ ?>