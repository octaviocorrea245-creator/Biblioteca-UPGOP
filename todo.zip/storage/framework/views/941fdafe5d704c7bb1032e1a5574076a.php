<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Alumnos</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <a href="<?php echo e(route('alumnos.create')); ?>"
           class="mb-4 inline-block bg-blue-600 text-white px-4 py-2 rounded">
            + Nuevo Alumno
        </a>

        <?php if(session('success')): ?>
            <div class="mb-4 text-green-600"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="mb-4">
            <input type="text" id="buscador" placeholder="Buscar por nombre, matrícula o carrera..."
                class="w-full border-gray-300 rounded shadow-sm p-2"
                onkeyup="buscarEnTabla()">
        </div>
        <table class="w-full bg-white shadow rounded">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-3 text-left">Matrícula</th>
                    <th class="p-3 text-left">Nombre</th>
                    <th class="p-3 text-left">Carrera</th>
                    <th class="p-3 text-left">Cuatrimestre</th>
                    <th class="p-3 text-left">Turno</th>
                    <th class="p-3 text-left">Estado</th>
                    <th class="p-3 text-left">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="p-3"><?php echo e($alumno->matricula); ?></td>
                    <td class="p-3"><?php echo e($alumno->nombre); ?></td>
                    <td class="p-3"><?php echo e($alumno->carrera->nombre); ?></td>
                    <td class="p-3"><?php echo e($alumno->cuatrimestre); ?></td>
                    <td class="p-3"><?php echo e($alumno->turno); ?></td>
                    <td class="p-3">
                        <span class="px-2 py-1 rounded text-sm
                            <?php echo e($alumno->estado === 'Activo' ? 'bg-green-100 text-green-700' : ''); ?>

                            <?php echo e($alumno->estado === 'Deudor' ? 'bg-yellow-100 text-yellow-700' : ''); ?>

                            <?php echo e($alumno->estado === 'Rezagado' ? 'bg-red-100 text-red-700' : ''); ?>">
                            <?php echo e($alumno->estado); ?>

                        </span>
                    </td>
                    <td class="p-3 flex gap-2">
                        <a href="<?php echo e(route('alumnos.edit', $alumno)); ?>"
                           class="bg-yellow-400 text-white px-3 py-1 rounded text-sm">Editar</a>
                        <form action="<?php echo e(route('alumnos.destroy', $alumno)); ?>" method="POST"
                              onsubmit="return confirm('¿Eliminar este alumno?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="bg-red-500 text-white px-3 py-1 rounded text-sm">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4">
            <?php echo e($alumnos->links()); ?>

        </div>
    </div>
    <script>
        function buscarEnTabla() {
            const input = document.getElementById('buscador').value.toLowerCase();
            const filas = document.querySelectorAll('tbody tr');
            filas.forEach(fila => {
                const texto = fila.innerText.toLowerCase();
                fila.style.display = texto.includes(input) ? '' : 'none';
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Biblioteca-UPGOP\resources\views/alumnos/index.blade.php ENDPATH**/ ?>